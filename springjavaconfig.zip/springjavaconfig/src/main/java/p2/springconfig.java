package p2;


import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import p1.Address;
import p1.student;
@Configuration
public class springconfig 
{
	@Bean("createadd")
	public Address createadd() 
	{
		Address add=new Address();
		add.setHouseno(100);
		add.setPincode(110076);
		add.setCity("Delhi");
		return add;
	}
     @Bean("createadd2")
	public Address createadd2() 
	{
		Address add=new Address();
		add.setHouseno(101);
		add.setPincode(110078);
		add.setCity("Chandigarh");
		return add;
	}
	@Bean
	public student createstu()
	{
		student stu=new student();
		stu.setName("Deepak");
		stu.setRollno(100);
		return stu;
	}

}
