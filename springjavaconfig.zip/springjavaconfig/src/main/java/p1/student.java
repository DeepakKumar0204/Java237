package p1;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
public class student {
	private int Rollno;
	private String Name;
	@Autowired
    @Qualifier("createadd2")
	private Address address;
	public int getRollno() {
		return Rollno;
	}
	public void setRollno(int rollno) {
		Rollno = rollno;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	//public Address getAddress() {
		//return address;
	//}
	public void setAddress(Address address) {
		this.address = address;
	}
	public void display() 
	{
		System.out.println("Name:"+Name);
		System.out.println("Rollno:"+Rollno);
		System.out.println("Address:"+address);
	    System.out.println("Address toString: " + address.toString());



	
	}
	
	
	

}
