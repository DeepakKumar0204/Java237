package p1;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import p2.springconfig;

public class m3 {
	public static void main(String[] args) {
		ApplicationContext context=new AnnotationConfigApplicationContext(springconfig.class);
		student stu=(student) context.getBean(student.class);
		Address add=(Address) context.getBean(Address.class);
		stu.display();




	}

}
